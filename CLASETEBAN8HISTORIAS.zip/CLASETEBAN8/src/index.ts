abstract class Historia {
    public numeroHistoria: number;
    private opciones: string[];

    constructor(numeroHistoria: number, opciones: string[]) {
        this.numeroHistoria = numeroHistoria;
        this.opciones = opciones;
    }

    mostrarOpciones(): string[] {
        return this.opciones;
    }

    descripcion(): string {
        return `Historia número ${this.numeroHistoria}`;
    }
}

class Genero extends Historia {
    public terror: string;
    public comedia: string;
    public accion: string;

    constructor(
        numeroHistoria: number,
        opciones: string[],
        terror: string,
        comedia: string,
        accion: string
    ) {
        super(numeroHistoria, opciones);
        this.terror = terror;
        this.comedia = comedia;
        this.accion = accion;
    }

    descripcion(): string {
        return `En la parte de ${this.terror} tenemos una historia espeluznante, 
    en ${this.comedia} una llena de risas, 
    y en ${this.accion} mucha adrenalina.`;
    }
}

class Personajes extends Historia {
    private personajes: string[];

    constructor(numeroHistoria: number, opciones: string[], personajes: string[]) {
        super(numeroHistoria, opciones);
        this.personajes = personajes;
    }

    elegirPersonaje(indice: number): string {
        if (indice >= 0 && indice < this.personajes.length) {
            return this.personajes[indice];
        }
        return "Personaje inválido";
    }

    get listaPersonajes(): string[] {
        return this.personajes;
    }


    descripcion(): string {
        return `Historia ${this.numeroHistoria} con personajes: ${this.personajes.join(", ")}`;
    }
}
class Juego {
    private historia: Historia;
    private genero: Genero;
    private personajes: Personajes;

    constructor(historia: Historia, genero: Genero, personajes: Personajes) {
        this.historia = historia;
        this.genero = genero;
        this.personajes = personajes;
    }

    iniciarJuego(): void {
        console.log("🎮 Bienvenido al juego interactivo");
        console.log(this.historia.descripcion());
    }

    getGeneros(): { terror: string; comedia: string; accion: string } {
        return {
            terror: this.genero.terror,
            comedia: this.genero.comedia,
            accion: this.genero.accion,
        };
    }

    getPersonajes(): string[] {
        return this.personajes.listaPersonajes;
    }
}

export { Historia, Genero, Personajes, Juego };

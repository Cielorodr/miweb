import { Genero, Personajes, Juego } from "./index";
import { select } from "@inquirer/prompts";

async function main() {
  const genero = new Genero(1, ["Opción 1", "Opción 2"], "Terror", "Comedia", "Acción");
  const personajes = new Personajes(1, ["Opción 1", "Opción 2"], [
    "Mario",
    "Luigi",
    "Peach",
    "Yoshi",
  ]);

  const juego = new Juego(genero, genero, personajes);

  while (true) {
    const option = await select({
      message: "Historias Interactivas",
      choices: [
        { name: "Comenzar Juego", value: "comienzo" },
        { name: "Descripción", value: "describir" },
        { name: "🚪 Salir", value: "salir" },
      ],
    });

    if (option === "comienzo") {
      // 1️⃣ Elegir género
      const eleccionGenero = await select({
        message: "Elige un género",
        choices: [
          { name: genero.terror, value: "terror" },
          { name: genero.comedia, value: "comedia" },
          { name: genero.accion, value: "accion" },
          { name: "📖 Descripción de géneros", value: "descripcion" },
        ],
      });

          if (eleccionGenero === "descripcion") {
      console.log(genero.descripcion()); // Usa polimorfismo
      continue; // vuelve al menú principal sin iniciar historia
    }

      // 2️⃣ Elegir personaje (con opción Descripción incluida)
      const eleccionPersonaje = await select({
        message: "Elige tu personaje",
        choices: [
          ...personajes.listaPersonajes.map((p: string, i: number) => ({
            name: p,
            value: i,
          })),
        ],
    });



    const personajeElegido = personajes.elegirPersonaje(eleccionPersonaje);

    // 3️⃣ Historia según género
    if (eleccionGenero === "terror") {
      console.log(`👻 ${personajeElegido} entra a una mansión oscura. Se oyen pasos...`);
      const paso1 = await select({
        message: "¿Qué haces?",
        choices: [
          { name: "Encender linterna", value: "linterna" },
          { name: "Correr hacia la salida", value: "correr" },
        ],
      });

      if (paso1 === "linterna") {
        console.log("🔦 Ves un fantasma amistoso que te ofrece ayuda...");
        const paso2 = await select({
          message: "¿Aceptas su ayuda?",
          choices: [
            { name: "Sí", value: "si" },
            { name: "No", value: "no" },
          ],
        });
        if (paso2 === "si") console.log("El fantasma te guía a salvo fuera de la mansión. ✅ ¡Final feliz!");
        else console.log("El fantasma desaparece y te pierdes en la oscuridad. ❌ Fin del juego.");
      } else {
        console.log("🏃 Tropiezas y caes en un agujero. ❌ Fin del juego.");
      }
    }

    else if (eleccionGenero === "comedia") {
      console.log(`😂 ${personajeElegido} entra a una fiesta llena de bromas.`);
      const paso1 = await select({
        message: "Un payaso te ofrece un pastel en la cara, ¿aceptas?",
        choices: [
          { name: "Sí", value: "si" },
          { name: "No", value: "no" },
        ],
      });

      if (paso1 === "si") {
        console.log("🤣 Todos se ríen contigo, te conviertes en el alma de la fiesta.");
        console.log("🎉 ¡Final feliz y divertido!");
      } else {
        console.log("😒 El payaso se molesta y te caes en una broma con cáscaras de plátano.");
        console.log("😂 Final gracioso aunque vergonzoso.");
      }
    }

    else if (eleccionGenero === "accion") {
      console.log(`💥 ${personajeElegido} está en medio de una persecución en auto.`);
      const paso1 = await select({
        message: "¿Qué haces?",
        choices: [
          { name: "Saltar del auto", value: "saltar" },
          { name: "Pelear con el villano", value: "pelear" },
        ],
      });

      if (paso1 === "saltar") {
        console.log("🏃 Saltas y ruedas por el suelo...");
        const paso2 = await select({
          message: "Un helicóptero aparece, ¿te subes?",
          choices: [
            { name: "Sí", value: "si" },
            { name: "No", value: "no" },
          ],
        });
        if (paso2 === "si") console.log("🚁 Escapas volando. ¡Final épico!");
        else console.log("💥 El auto explota cerca de ti. ❌ Fin del juego.");
      } else {
        console.log("👊 Luchas con valentía y derrotas al villano.");
        console.log("🏆 ¡Final heroico!");
      }
    }
  }

    else if (option === "describir") {
    console.log("📖 Descripciones:");
    console.log(genero.descripcion());
    console.log(`${personajes.descripcion()} y con genero ${genero.descripcion()}`);
  }

  else if (option === "salir") {
    console.log("Gracias por utilizar nuestros servicios.");
    break;
  }
}
}

main();

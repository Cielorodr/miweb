# Informe: TypeScript y Programación Orientada a Objetos (POO)

## 1. ¿Qué es TypeScript y en qué se diferencia de JavaScript?
**TypeScript (TS)** es un superconjunto de **JavaScript (JS)** desarrollado por Microsoft que añade **tipado estático** y características de POO (Programación Orientada a Objetos).  
- **JS** es dinámico: no requiere definir tipos.  
- **TS** es estático: permite definir tipos (`string`, `number`, `boolean`, etc.), lo que ayuda a detectar errores en tiempo de compilación.  
- TS **se transpila** a JS para ejecutarse en navegadores o Node.js.  

```ts
// JavaScript
let mensaje = "Hola";
mensaje = 123; // No hay error en JS

// TypeScript
let mensaje: string = "Hola";
mensaje = 123; // ❌ Error de compilación
```

---

## 2.  Que Ventajas ofrece TypeScript para trabajar con  POO
- Tipado fuerte y estático.  
- Soporte nativo para **clases, interfaces, modificadores de acceso, herencia y abstracción**.  
- Facilita proyectos grandes y colaborativos.  
- Mejor autocompletado y documentación en editores como VS Code.  

---

## 3.  Que son los Modificadores de acceso(public,private,protected)
En TS existen **public, private y protected**:  
- `public`: Accesible desde cualquier lugar (por defecto).  
- `private`: Solo accesible dentro de la clase.  
- `protected`: Accesible dentro de la clase y subclases.  

```ts
class Persona {
  public nombre: string;
  private edad: number;
  protected correo: string;

  constructor(nombre: string, edad: number, correo: string) {
    this.nombre = nombre;
    this.edad = edad;
    this.correo = correo;
  }
}
```

---

## 4.    Que es  un readonly y para que se usa 
Se usa para definir propiedades que **solo se pueden asignar en el constructor** y no se pueden modificar después.  

```ts
class Producto {
  readonly codigo: number;
  constructor(codigo: number) {
    this.codigo = codigo;
  }
}

const p = new Producto(123);
p.codigo = 456; // ❌ Error
```

---

## 5. Definición de clases y objetos en TypeScript

En **TypeScript**, una **clase** es un molde que permite crear **objetos** con propiedades y métodos.  
Un **objeto** es una instancia de esa clase.

### Ejemplo :
```ts
class Animal {
  nombre: string; // Propiedad

  constructor(nombre: string) { // Constructor
    this.nombre = nombre;
  }

  sonido(): void { // Método
    console.log("Hace un sonido");
  }
}

// Crear un objeto (instancia de la clase)
const perro = new Animal("Firulais");
console.log(perro.nombre); // Firulais
perro.sonido(); // Hace un sonido
```


## 6.  Que son los Constructores y para que sirven 
Los **constructores** son métodos especiales que inicializan objetos cuando se crean con `new`.  

```ts
class Coche {
  constructor(public marca: string, public modelo: string) {}
}

const carro = new Coche("Toyota", "Corolla");
console.log(carro.marca); // Toyota
```

---

## 7. Herencia en TS y como se implementa (extends/super)
Una clase puede **heredar** de otra usando `extends`. Se puede llamar al constructor padre con `super`.  

```ts
class Animal {
  constructor(public nombre: string) {}
  mover() {
    console.log("Se mueve");
  }
}

class Perro extends Animal {
  ladrar() {
    console.log("Guau");
  }
}

const dog = new Perro("Bobby");
dog.mover(); // Se mueve
dog.ladrar(); // Guau
```

---
## 9. Clases abstractas y diferencia con una clase normal  

- **Clase normal:**  
  Se puede instanciar directamente con `new` y usar sus métodos.  

- **Clase abstracta:**  
  No se puede instanciar directamente, solo sirve como **base** para otras clases.  
  Puede tener métodos **abstractos** (sin implementación) que obligan a las subclases a implementarlos.  

### 📝 Ejemplo:
```ts
// Clase normal
class Animal {
  constructor(public nombre: string) {}
  sonido(): void {
    console.log("Hace un sonido genérico");
  }
}

const perro = new Animal("Firulais");
perro.sonido(); // ✅ Se puede instanciar directamente

// Clase abstracta
abstract class Empleado {
  constructor(public nombre: string) {}
  
  abstract calcularSalario(): number; // Método abstracto (sin implementación)
  
  mostrarInfo(): void {
    console.log(`Empleado: ${this.nombre}`);
  }
}

class Programador extends Empleado {
  calcularSalario(): number {
    return 3000; // Implementación obligatoria
  }
}

const dev = new Programador("Carlos");
dev.mostrarInfo(); // Empleado: Carlos
console.log(dev.calcularSalario()); // 3000

// ❌ Error: no se puede instanciar una clase abstracta
// const e = new Empleado("Juan");






```

---

## 10. Interfaces en TS y en que se diferencia de una clase  abstracta
Una **interface** define un contrato de propiedades y métodos, pero no implementa lógica.  
- Diferencia con clase abstracta: la interface **no genera código JS**, solo sirve en tiempo de compilación.  

```ts
interface Animal {
  nombre: string;
  hacerSonido(): void;
}

class Gato implements Animal {
  constructor(public nombre: string) {}
  hacerSonido(): void {
    console.log("Miau");
  }
}
```

---

## 11. Ejemplo mínimo de cada pilar de POO en TS (1 linea de codigo por concepto )
- **Abstracción:**  
```ts
interface Figura { area(): number; }
```
- **Encapsulamiento:**  
```ts
class Cuenta { private saldo: number = 0; }
```
- **Herencia:**  
```ts
class Ave { volar(){} } class Aguila extends Ave {}
```
- **Polimorfismo:**  
```ts
class A { hablar(){console.log("A");} } 
class B extends A { hablar(){console.log("B");} }
```

---

## 12. Configuración de TypeScript con Node.js y VS Code
1. Instalar Node.js desde [nodejs.org](https://nodejs.org).  
2. Crear carpeta de proyecto y ejecutar:  
   ```bash
   npm init -y
   npm install typescript --save-dev
   npx tsc --init
   ```
3. Crear archivo `index.ts` y compilar:  
   ```bash
   npx tsc
   node index.js
   ```
4. Instalar extensión oficial de **TypeScript** en VS Code para autocompletado.  
npx tsc

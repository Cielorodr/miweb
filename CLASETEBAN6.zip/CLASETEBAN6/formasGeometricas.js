//formas geometricas
//encapsulamiento
//herencia
//1 clase 3 hijos

class Formas {
    #parte;
    constructor(color, tipo, parte) {
        this.color = color;
        this.tipo = tipo;
        this.#parte = parte;
    }

    parte() {
        return this.#parte;
    }
    mostrarArea(){}
}

class Circulo extends Formas {
    constructor(color, tipo, radio) {
        super(color, tipo, radio); 
    }

    calcularArea() {
        return Math.PI * this.parte() * this.parte();
    }

    representaPlaneta() {
        console.log(`El planeta es de color ${this.color}, es de tipo ${this.tipo}, su área es ${this.calcularArea()} y su radio es ${this.parte()}`);
    }

    mostrarArea() {
        console.log(`El área del círculo es: ${this.calcularArea()}`);
    }
}

class Cuadrado extends Formas {
    constructor(color, tipo, lado) {
        super(color, tipo, lado); 
    }

    calcularArea() {
        return this.parte() * this.parte();
    }

    representaCaja() {
        console.log(`La caja es de color ${this.color}, es de tipo ${this.tipo}, su área es ${this.calcularArea()} y su lado es ${this.parte()}`);
    }
        mostrarArea() {
        console.log(`El área del cuadrado es: ${this.calcularArea()}`);
    }
}

class Triangulo extends Formas {
    constructor(color, tipo, base, altura) {
        super(color, tipo, base); 
        this.altura = altura;
    }

    calcularArea() {
        return (this.parte() * this.altura) / 2;
    }

    representaPiramide() {
        console.log(`La pirámide es de color ${this.color}, es de tipo ${this.tipo}, su área es ${this.calcularArea()}, su base es ${this.parte()} y su altura es ${this.altura}`);
    }
        mostrarArea() {
        console.log(`El área del triangulo es: ${this.calcularArea()}`);
    }
}

export { Formas, Circulo, Cuadrado, Triangulo };
import { Formas,Circulo,Triangulo,Cuadrado} from "./formasGeometricas.js";


const circulo1 = new Circulo("rojo", "circular", 45, );
const cuadrado1 = new Cuadrado("azul", "cuadrado", 10);
const triangulo1 = new Triangulo("verde", "triangular", 5,10);

cuadrado1.representaCaja();
cuadrado1.mostrarArea();
triangulo1.representaPiramide();
triangulo1.mostrarArea();
circulo1.representaPlaneta();
circulo1.mostrarArea();




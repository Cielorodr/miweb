class Animal {
    constructor(peso, especie, edad, tamaño) {
        this.peso = peso;
        this.especie = especie;
        this.edad = edad;
        this.tamaño = tamaño;

    }

    dormir() {
        console.log(`El aniaml de la especie ${this.especie}esta momiendo`);

    }
    comer() {
        console.log(`El aniaml de la especie ${this.especie}esta comiendo`);

    }
    sonido() {
            console.log("No todos los animales hacen el mismo sonido");
        



    }
}


class Perro extends Animal {
    sonido() {
        console.log("guau guau"); //overriding
    }
}

class Gato extends Animal {
    sonido() {
        console.log("miauuuu"); //overriding
    }
}

class Vaca extends Animal {
    sonido() {
        console.log("muuuu"); //overriding
    }
}



export { Animal, Gato, Perro, Vaca };




//formas geometricas
//encapsulamiento
//herencia
//1 clase 3hijos


class Persona {
    constructor(nombre, edad, telefono, email) {
        this.nombre = nombre;
        this.edad = edad;
        this.telefono = telefono;
        this.email = email;

    }

    trabajar() {
        console.log(`${this.nombre} esta trabajando`);
    }
    dormir() {
        console.log(`${this.nombre} esta durmiendo`);
    }
    ocupacion() {
        console.log(`${this.nombre} es un profesor`);
    }
}

class Estudiante extends Persona {
    constructor(nombre, edad, telefono, email,curso) {
        super(nombre, edad, telefono, email);
        this.curso = curso;
    }
    ocupacion() {
        console.log(`${this.nombre} es un estudiante y esta en el curso ${this.curso}`);
    }
}


class Profesor extends Persona {
    constructor(nombre, edad, telefono, email,materia){
        super(nombre, edad, telefono, email);
        this.materia = materia;
    }
    ocupacion() {
        console.log(`${this.nombre} es un profesor de ${this.materia}`);
    }
}

export { Persona, Estudiante, Profesor };
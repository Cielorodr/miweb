RF1 – Registro y autenticación de usuarios
[   ] Cumple

RF2 – Administración de sensores IoT
[   ] Cumple

RF3 – Visualización de datos en tiempo real
[   ] Cumple

RF4 – Generación de alertas automáticas
[   ] Cumple

RF5 – Reportes históricos (PDF/Excel)
[   ] Cumple

RF6 – Multiusuario (roles administrador y técnico)
[   ] Cumple

Uso de Tailwind CSS para el diseño
[   ] Cumple

Diseño responsive (adaptable a móviles, tablets y PC)
[   ] Cumple

Implementación de favicon
[   ] Cumple

Carga correcta de imágenes
[   ] Cumple

Funcionamiento de enlaces internos/externos
[   ] Cumple

Pruebas de ortografía y redacción
[   ] Cumple